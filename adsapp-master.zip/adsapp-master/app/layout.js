import { Inter } from "next/font/google";
import "bootstrap/dist/css/bootstrap.min.css";
import Script from 'next/script';
import "../styles/globals.css";
import "../styles/style.css";
import Nav from "./components/Nav";
import Footer from "./components/Footer";


const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "รับทำโฆษณาออนไลน์ สายเทา โฆษณาสายเทาเพื่อธุรกิจของคุณ",
  description: "รับทำโฆษณาออนไลน์สายเทา ผู้เชี่ยวชาญด้านการตลาดบน Google, YouTube และ Facebook",
  keywords: "ยิงads,facebook,สายเทา,โฆษณา,ยิงads facebook สายเทา,รับยิงads,รับยิงแอด สายเทา,facebook ads,google ads,google,รับยิงแอด,ads,รับทำโฆษณา,รับโฆษณา,Facebook,การตลาด,โฆษณาออนไลน์,เว็บไซต์,ตลาดเป้าหมาย,โฆษณาบนโซเชียลมีเดีย,Google Ads,การโฆษณาบน Facebook,การโฆษณาออนไลน์บนสื่อต่าง ๆ,การตลาดออนไลน์,การโปรโมท,โฆษณา Facebook,การโฆษณา Google,การโฆษณาสินค้า,การโฆษณาโปรโมชั่น,วิธีการโฆษณา,ความสำเร็จในการตลาด,บริการโฆษณา,การตลาดออนไลน์บน Facebook,การโฆษณาบนเว็บ,การวางแผนโฆษณา,รับจ้างโฆษณา",
  image:"https://service-ads.com/img/ads.jpg",
  name: "adsmanager",
  canonical:'https://service-ads.com',

};

export default function RootLayout({ children }) {


  return (
    <html lang="en">
   <meta name="google-site-verification" content="RUGTR3VbcF6w2Ejs1n1-0CThkzCgXGNxswXwfbO0D0s" />
   <Script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "Person",
              "name": "adsmanager",
              "url": "https://service-ads.com/",
              "Image": "https://service-ads.com/img/ads.jpg",
              "sameAs": [
                "https://service-ads.com/favicon.ico"
              ]
            }
          `}
        </Script>
    
   <meta name="robots" content="index, follow" />

<meta name="author" content="adsmanager" />

<meta property="og:title" content="รับทำโฆษณาออนไลน์สายเทา" />
<meta property="og:description" content="รับทำโฆษณาออนไลน์สายเทา Google, YouTube, Facebook" />
<link rel="canonical" href='https://service-ads.com' />
<meta name="twitter:image" content="https://service-ads.com/img/ads.jpg" />
      <meta property="og:image" content="https://service-ads.com/img/ads.jpg" />
      <body className={inter.className}>
        <Nav/>
        {children}
       
     
        <Footer/>
        </body>
        <Script async src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></Script>

    </html>
  );
}
