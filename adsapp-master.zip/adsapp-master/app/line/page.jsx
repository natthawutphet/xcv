"use client"

import { useEffect } from 'react';

const LineIndex = () => {
  useEffect(() => {

    window.location.href = "https://lin.ee/JwrDPgA";
  }, []);

  return (
    <>

    </>
  );
}

export default LineIndex;
